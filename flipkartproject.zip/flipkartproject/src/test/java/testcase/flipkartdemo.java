package testcase;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class flipkartdemo {
	WebDriver driver;
	@BeforeMethod
	public  void getBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe");
	    // driver.get(propertyfile1.getProperty("ChromeExe"));
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		driver.get("https://www.flipkart.com");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//button[@class='_2AkmmA _29YdH8']")).click();
		String Actual_title="Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!";
		String Expected_title=driver.getTitle();
		Assert.assertEquals( Actual_title,Expected_title);
	}
	@Test
	public void flipkart_validation()
	{
		WebElement Search_Box=driver.findElement(By.xpath("//input[@type='text' and @name='q']"));
		Search_Box.sendKeys("Tv");
		WebElement Search_btn=driver.findElement(By.xpath("//button[@class='vh79eN']"));
		Search_btn.click();
		List<WebElement> product_name=driver.findElements(By.xpath("//div[@class='_3wU53n']"));
		String product_title = null;
		String product_values;
		int price = 0;
		for(int i=0;i<product_name.size();i++)
		{
			 product_title=product_name.get(i).getText();
			 //System.out.println(product_title);
			
		}
		
		List<WebElement> product_price=driver.findElements(By.xpath("//div[@class='_1vC4OE _2rQ-NK']"));
       
		for(int j=0;j<product_price.size();j++)
        {
        	 product_values=product_price.get(j).getText().replaceAll("[^0-9]", "");
        	 price=Integer.parseInt(product_values);
        	 //System.out.println(price);
        	
        }
		 HashMap<String,Integer> object=new HashMap<String,Integer>();
		 object.put(product_title,price);
		 System.out.println(object.get(product_title)); 
		 
		 
		
		
	}
}
